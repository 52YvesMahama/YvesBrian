<?php


session_start();
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));

$prisonerID = 0;
$update = false;

$IDNumber = '';
$firstname = '';
$lastname = '';
$phonenumber = '';
$address = '';
$placeofbirth = '';
$dob = '';
$crimeID = '';
$cellID = '';
$status = '';
$educlevel = '';
$gender = '';
$nationality = '';

if (isset($_POST['save'])){
	$prisonerID = $_POST['prisonerID'];
	$IDNumber = $_POST['IDNumber'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$placeofbirth = $_POST['placeofbirth'];
	$dob = $_POST['dob'];
	$crimeID = $_POST['crimeID'];
	$cellID = $_POST['cellID'];
	$status = $_POST['status'];
	$educlevel = $_POST['educlevel'];
	$gender = $_POST['gender'];
	$nationality = $_POST['nationality'];

	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";


header("location: addNewPrisoner1.php");

	$mysqli->query("INSERT INTO inmates
	 (
	 IDNumber, 
	 firstname, 
	 lastname, 
	 phonenumber, 
	 address, 
	 placeofbirth, 
	 dob, 
	 crimeID, 
	 cellID,
	 status, 
	 educlevel, 
	 gender, 
	 nationality
	 ) 

	 VALUES('$IDNumber', '$firstname', '$lastname', '$phonenumber', '$address', '$placeofbirth', '$dob', '$crimeID', '$cellID', '$status', '$educlevel', '$gender', '$nationality') ") or 
	die($mysqli->error);
}

if (isset($_GET['delete'])){
	$prisonerID = $_GET['delete'];
	$mysqli->query("DELETE FROM inmates WHERE prisonerID=$prisonerID") or die($mysqli->error());



	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";

header("location: addNewPrisoner1.php");

}

if (isset($_GET['edit'])){
	$prisonerID = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM inmates WHERE prisonerID=$prisonerID") or die($mysqli->error());
	// if (count($result) == 1 ){
	if (mysqli_num_rows($result) == 1 ){
		$row = $result->fetch_array();

	$IDNumber = $row['IDNumber'];
	$firstname = $row['firstname'];
	$lastname = $row['lastname'];
	$phonenumber = $row['phonenumber'];
	$address = $row['address'];
	$placeofbirth = $row['placeofbirth'];
	$dob = $row['dob'];
	$crimeID = $row['crimeID'];
	$cellID = $row['cellID'];
	$status = $row['status'];
	$educlevel = $row['educlevel'];
	$gender = $row['gender'];
	$nationality = $row['nationality'];

	}

}

if (isset($_POST['update'])){
	$prisonerID = $_POST['prisonerID'];
	$IDNumber = $_POST['IDNumber'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$placeofbirth = $_POST['placeofbirth'];
	$dob = $_POST['dob'];
	$crimeID = $_POST['crimeID'];
	$cellID = $_POST['cellID'];
	$status = $_POST['status'];
	$educlevel = $_POST['educlevel'];
	$gender = $_POST['gender'];
	$nationality = $_POST['nationality'];


		$mysqli->query("UPDATE inmates SET IDNumber='$IDNumber', firstname='$firstname', lastname='$lastname', phonenumber ='$phonenumber', address='$address', placeofbirth='$placeofbirth', dob='$dob', crimeID='$crimeID', cellID='$cellID', status='$status', educlevel='$educlevel', gender='$gender', nationality='$nationality' WHERE prisonerID=$prisonerID")or die($mysqli->error);

		$_SESSION['message'] = "Record has been updated!";
		$_SESSION['msg_type'] = "warning";

		header('location: addNewPrisoner1.php');

}