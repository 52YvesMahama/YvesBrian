
<!DOCTYPE html>
  <html>
    <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">  
    </head>
        <link rel="stylesheet" type="text/css" href="../../css/css.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssY.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssNewPrisoner.css">




         
<title>Prison Munzenze</title>
          <body>
          <section class="container">
              <div id="subcontainer1">
                    <center><h1>The Ministry of Interior and Department of National Security. </h1></center>
                      <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
                            <h3>Correction & rehabilitation centre</h3>
                </div>
                <div id="subcontainer2">
                   <div class="nav">
                      <ul>
                        <li class="home"><a href="../../index.html">Home</a></li>
                        <li class="contact"><a href="../../pages/contact.php">Contact</a></li>
                        <li class="about"><a href="../../pages/about.php">About Us</a></li>
<!--                    <li class="about"><a href="pages/about.html">About Us</a></li>  -->                        <li class="about"><a class="active" href="Login.php" style="margin-left: 400px; width: 100px;">Logout</a></li>
                      </ul>
                   </div>

                <div id="subcontainer3">
                  <body>

    <div class="container">
    <div class="wrapper">
<!--     <div class="header">
 -->   
    <h2>Jailor Dashord</h2>  Welcome (who logged_in)
  </div>

        <h3>Add New Prisoner</h3>

<?php require_once 'processprison.php'; ?>


<?php

if(isset($_SESSION['message'])): ?>

  <div class="alert alert-<?=$_SESSION['msg_type']?>">
 
    <?php
    echo $_SESSION['message'];
    unset($_SESSION ['message']);
    ?>

</div>
<?php endif ?>

    <div class="container">

<?php
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));
$result = $mysqli ->query("SELECT * FROM inmates ORDER BY prisonerID ASC") or die($mysqli->error);
 //pre_r($result);
?>


<?php 

  function pre_r($array){
    echo '<pre>';
    print_r($array);
    echo '</pre>';
  }

?>


<div class="row justify-content-center">
  <form action="processPrison.php" method="POST">


    <input type="hidden"name ="prisonerID" value="<?php echo $prisonerID; ?>">
    <div class="input-group">
    <div class="form-group">
    <label> ID Number </label>
    <input type="text" name="IDNumber" class="form-control"
    value="<?php echo $IDNumber; ?>" placeholder="Please Enter ID Number" required>
    <span class ="help-block"></span>
    </div>

    <div class="form-group">
    <label> First Name </label>
    <input type="text" name="firstname" class="form-control"
    value="<?php echo $firstname; ?>" placeholder="Enter First Name" required>
    <span class ="help-block"></span>
    </div>

    
    <div class="form-group">
    <label> Last Name </label>
    <input type="text" name="lastname" class="form-control"
    value="<?php echo $lastname; ?>" placeholder="Enter Last Name" required>
    </div>


    <div class="form-group">
    <label> Phone Number </label>
    <input type="text" name="phonenumber"  class="form-control"
    value="<?php echo $phonenumber; ?>" placeholder="Enter Phone number" required> 
    </div>

    <div class="form-group">
    <label> Address </label>
    <input type="text" name="address"  class="form-control"
    value="<?php echo $address; ?>" placeholder="Enter Address" required> 
    </div>

    <div class="form-group">
    <label> Place of Birth </label>
    <input type="text" name="placeofbirth"  class="form-control"
    value="<?php echo $placeofbirth; ?>" placeholder="Enter Place Of Birth" required> 
    </div>

    <div class="form-group">
    <label> Date of Birth </label>
    <input type="text" name="dob"  class="form-control"
    value="<?php echo $dob; ?>" placeholder="Enter dob" required>
    </div>

    <div class="form-group">
    <label> Crime ID </label>
    <input type="text" name="crimeID"  class="form-control"
    value="<?php echo $crimeID; ?>" placeholder="Enter crime ID" required> 
    </div>

    <div class="form-group">
    <label> Cell ID </label>
    <input type="text" name="cellID"  class="form-control"
    value="<?php echo $cellID; ?>" placeholder="Enter cellID" required> 
    </div>

    <div class="form-group">
    <label> Status </label>
    <input type="text" name="status"  class="form-control"
    value="<?php echo $status; ?>" placeholder="Enter status" required> 
    </div>

    <div class="form-group">
    <label> Education Level </label>
    <input type="text" name="educlevel"  class="form-control"
    value="<?php echo $educlevel; ?>" placeholder="Enter education level" required> 
    </div>

    <div class="form-group">
    <label> Gender </label>
    <input type="text" name="gender"  class="form-control"
    value="<?php echo $gender; ?>" placeholder="Enter Gender" required> 
    </div>

    <div class="form-group">
    <label> Nationality </label>
    <input type="text" name="nationality"  class="form-control"
    value="<?php echo $nationality; ?>" placeholder="Enter Nationality" required> 
    </div>

   <div class="form-group">
      <?php 
        if ($update == true):
      ?>

    <button type="submit" class="btn btn-info" name="update">Update</button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary" name="save">Save</button>
    <?php endif; ?>
    </div>
  </form>
</div>
          <div class="input-group">
           <div class="nav">
            </div>
            <div class="form-group">
          </div>              
      </form>
     </div>
    </div>  
  </div>
</div>
            <div id="subcontainer4">         
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
          </div>
        </div>
      </div>

            </div>
          </section>
       </body> 
    </head>
  </html> 


