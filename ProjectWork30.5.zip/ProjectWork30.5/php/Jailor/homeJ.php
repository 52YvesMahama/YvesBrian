<?php

session_start();
	include("config.php");

?>

<!DOCTYPE html>
  <html>
    <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">  
    </head>
        <link rel="stylesheet" type="text/css" href="../../css/css.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssY.css">
        <link rel="stylesheet" type="text/css" href="../css/csshomeJ.css">

         <title>Prison Munzenze</title>
          <body>
          <section class="container">
              <div id="subcontainer1">
                    <center><h1>The Ministry of Interior and Department of National Security. </h1></center>
                      <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
                            <h3>Correction & rehabilitation centre</h3>
                </div>
                <div id="subcontainer2">
                   <div class="nav">
                      <ul>
                        <li class="home"><a href="../../index.html">Home</a></li>
                        <li class="contact"><a href="../../pages/contact.php">Contact</a></li>
                        <li class="about"><a href="../../pages/about.php">About Us</a></li>
<!--                         <li class="about"><a href="pages/about.html">About Us</a></li>  -->                        <li class="about"><a class="active" href="Login.php" style="margin-left: 400px; width: 100px;">Logout</a></li>
                      </ul>
                   </div>

                <div id="subcontainer3">
                  <body>

    <div class="container">
    <div class="wrapper">
    <h2>Jailor Dashord</h2>  Welcome (who logged_in)
  </div>

      <form> 
        <h3>Activities to perfom</h3>
          <div class="input-group">

             <div class="nav">
              <ul>
                  <li class="home"><a href="addNewPrisoner.php">Add new prisoner</a></li>
                  <li class="contact"><a href="resultsPrisoners.php">prisoners information </a></li>
                        <li class="about"><a href="cellList.php">cell information</a></li>

              </ul>
          </div>
              <div class="form-group">
          </div>              
      </form>
    </div>  
  </div>
</div>

            <div id="subcontainer4">
            
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
          </div>
        </div>
      </div>

            </div>
          </section>
       </body> 
    </head>
  </html> 