<?php

session_start();
	include("connectionn.php");
	include("functionn.php");
	
	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		// Something was posted
	$username = $_POST['username'];
	$pwd = $_POST['pwd'];
	$staff_id = $_POST['staff_id'];
	$type = $_POST['type'];
		
		if(!empty($username) && !empty($password) && !is_numeric($username))
		{
			
			// save to the database.
			// $userID = random_num(20);
			$query = "insert into users (username, password, staff_id, type) values ('$username','$password','$staff_id','$type')";
			
			mysqli_query($con, $query);
			
			echo "$query";
			// header("location: loginn.php");
			die;
		}else
		{
			echo "User name or password incorrect!";
		}
		
	}
	

?>

<!DOCTYPE html>
<html>
<head>
	<title>SignUp</title>
</head>
<body>


	<style type="text/css"></style>

	<div id="box">
		<form method="post">
<!DOCTYPE html>
<html>
<head>
	<title>SignUp</title>
</head>
<body>


	<style type="text/css"></style>

	<div id="box">
		<form method="post">
					<div style="font-size: 20px; margin :10px;">SignUp</div>

	<input type="text" name="username" placeholder="username"> <br> <br>
	<br>
	<input type="password" name="pwd" placeholder="password">  <br> <br>
	<br>
	<input type="text" name="staff_id" placeholder="staff_id"> <br> <br>
	<br>
	<input type="text" name="type" placeholder="type"> <br> <br>
	<br>
	<button type="submit" name="submit"> Sign up</button> <br> <br>

</body>
</html>			<a href="loginn.php">Login</a> <br> <br> 
</body>
</html>