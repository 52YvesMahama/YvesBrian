<?php

session_start();
	include("connectionn.php");
	include("functionn.php");
	
	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		// Something was posted
	$username = $_POST['username'];
	$password = $_POST['password'];
	$staff_id = $_POST['staff_id'];
	$type = $_POST['type'];
		
		if(!empty($username) && !empty($password) && !is_numeric($username))
		{
			
			// read from the database.
			//$userID = random_num(20);
			$query = "select * from users where username = '$username' limit 1";
			
			$result = mysqli_query($con, $query);
			
			if($result)
			{
				if($result && mysqli_num_rows($results) > 0)
				{
					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['password'] === $password)
					
					{
						$_SESSION['userID'] = $user_data['userID'];
						header("location: home.php");
						
						die;
					}
				}
			}
			echo "User name or password incorrect!";
		
		}else
		{
			echo "User name or password incorrect!";
		}
		
	}

?>

<!-- <!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>


	<style type="text/css"></style>

	<div id="box">
		<form method="post">
			<div style="font-size: 20px; margin :10px;">Login</div>

			<input type="text" name="username"> <br> <br>
			<input type="password" name="pass"> <br> <br>

			<input type="submit" value="login"> <br> <br>

			<a href="signupp.php">SignUp</a> <br> <br> 
		</form>
</body>
</html> -->


<!DOCTYPE html>
  <html>
    <head>
	<meta name="viewport" content="width=device-width, initial-scale=1">  
    </head>
        <link rel="stylesheet" type="text/css" href="../../css/css.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssY.css">
        <link rel="stylesheet" type="text/css" href="../../css/csslog.css">
        <title>Prison Munzenze</title>
          <body>
          <section class="container">
              <div id="subcontainer1">
                    <center><h1>The Ministry of Interior and Department of National Security. </h1></center>
                      <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
                            <h3>Correction & rehabilitation centre</h3>
                </div>
                <div id="subcontainer2">
                   <div class="nav">
                      <ul>
                        <li class="home"><a class="active" href="../index.html">Home</a></li>
                        <li class="contact"><a href="pages/contact.html">Contact</a></li>
                        <li class="about"><a href="pages/about.html">About Us</a></li>
<!--                         <li class="about"><a href="pages/about.html">About Us</a></li>  -->                        <li class="about"><a class="active" href="Login.php" style="margin-left: 400px; width: 100px;">Login</a></li>
                      </ul>
                   </div>

                <div id="subcontainer3">
                  <body>

    <div class="container">
    <div class="wrapper">
<!--     <div class="header">
 -->    <h2>Login</h2>
  </div>

			<form method="POST"> 
			    <div class="input-group">
			        <div class="form-group">
			          	<label>Username</label>
				<input type="text" name="username" class="form-control" required>
					<span class="help-block"></span>
					</div>
			        
			        <div class="input-group">
			          	<label>Password</label>
				<input type="password" name="pwd" class="form-control"required>
					<span class="help-block"></span>
					</div>

            <div class="input-group">
				<button type="submit" class="btn" name="submit"> Login</button>
			</div>
			</form>
		</div>  
	</div>
</div>

            <div id="subcontainer4">
            
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="pages/contact.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="pages/about.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
          </div>
        </div>
      </div>

            </div>
          </section>
       </body> 
    </head>
  </html> 