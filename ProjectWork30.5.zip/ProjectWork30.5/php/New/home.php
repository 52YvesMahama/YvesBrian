<?php

session_start();
	include("connectionn.php");
	include("functionn.php");

	// $user_data = check_login($con);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Munzenze</title>
</head>
<body>

	<a href="logout.php">Logout</a>
	<h1> this is the home page</h1>

	<br>
	Hello, Welcome Mr 
</body>
</html>