<?php

// Validate for users over 18 only
function validateAge($ageString)
{
    // Convert $ageString to a php date
    $ageDate = strtotime($then);
  
    $input = '06/10/2011 19:00:02';
	$date = strtotime($input);
	echo date('d/M/Y h:i:s', $date);


    // Get todays date from the system
    $currentDate = 
    
    PHP date()
    
    // Subtract $ageDate from $currentDate 
    $ageDifference = 
    
    // Check if $ageDifference is greater than 18years
    if($ageDifference < 18)  {
        die('Not 18+'); 
    }
}

?>