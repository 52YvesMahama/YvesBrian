<?php


session_start();
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));

$prisonerIDD = 0;
$update = false;

$prisonerID = '';
$BlockID = '';
$cellID = '';
$crimeID = '';




if (isset($_POST['save'])){

	$prisonerIDD = $_POST['prisonerIDD'];
	$prisonerID = $_POST['prisonerID'];
	$BlockID = $_POST['BlockID'];
	$cellID = $_POST['cellID'];
	$crimeID = $_POST['crimeID'];


	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";

	$mysqli->query("INSERT INTO prisoner (prisonerID, BlockID, cellID, crimeID) VALUES('$prisonerID', '$BlockID',  '$cellID', '$crimeID') ") or 
	die($mysqli->error);

		header("location: ../addPrisoner.php");
}


if (isset($_GET['delete'])){
	$prisonerIDD = $_GET['delete'];
	$mysqli->query("DELETE FROM prisoner WHERE prisonerIDD=$prisonerIDD") or die($mysqli->error());



	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";

		header("location: ../addPrisoner.php");

}

if (isset($_GET['edit'])){
	$prisonerIDD = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM prisoner WHERE prisonerIDD=$prisonerIDD") or die($mysqli->error());
	// if (count($result) == 1 ){
	if (mysqli_num_rows($result) == 1 ){
		$row = $result->fetch_array();

	
	$prisonerID = $row['prisonerID'];
	$BlockID = $row['BlockID'];
	$cellID = $row['cellID'];
	$crimeID = $row['crimeID'];
	}

}

if (isset($_POST['update'])){
	$prisonerIDD = $_POST['prisonerIDD'];
	$prisonerID = $_POST['prisonerID'];
	$BlockID = $_POST['BlockID'];
	$cellID = $_POST['cellID'];
	$crimeID = $_POST['crimeID'];

		$mysqli->query("UPDATE prisoner SET prisonerID= '$prisonerID', BlockID='$BlockID', cellID='$cellID', crimeID ='$crimeID' WHERE prisonerIDD=$prisonerIDD")or die($mysqli->error);

		$_SESSION['message'] = "Record has been updated!";
		$_SESSION['msg_type'] = "warning";

		header("location: ../addPrisoner.php");

}