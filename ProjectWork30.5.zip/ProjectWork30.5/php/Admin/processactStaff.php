<?php


session_start();
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));

$Sactivity_ID = 0;
$update = false;

$actName = '';
$Sdurarion = '';
$permutationID = '';

if (isset($_POST['save'])){
	$Sactivity_ID = $_POST['Sactivity_ID'];
	$actName = $_POST['actName'];
	$Sdurarion = $_POST['Sdurarion'];
	$permutationID = $_POST['permutationID'];


	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";

	$mysqli->query("INSERT INTO activitystafff (actName, Sdurarion, permutationID) VALUES('$actName', '$Sdurarion', '$permutationID') ") or 
	die($mysqli->error);
		header("location: addactStaff.php");

}


if (isset($_GET['delete'])){
	$Sactivity_ID = $_GET['delete'];
	$mysqli->query("DELETE FROM activitystafff WHERE Sactivity_ID=$Sactivity_ID") or die($mysqli->error());



	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";

		header("location: addactStaff.php");

}

if (isset($_GET['edit'])){
	$Sactivity_ID = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM activitystafff WHERE Sactivity_ID=$Sactivity_ID") or die($mysqli->error());
	// if (count($result) == 1 ){
	if (mysqli_num_rows($result) == 1 ){
		$row = $result->fetch_array();

	
	$actName = $row['actName'];
	$Sdurarion = $row['Sdurarion'];
	$BlockID = $row['BlockID'];
	$permutationID = $row['permutationID'];
	
	}

}

if (isset($_POST['update'])){
	$Sactivity_ID = $_POST['Sactivity_ID'];
	$actName = $_POST['actName'];
	$Sdurarion = $_POST['Sdurarion'];
	$permutationID = $_POST['permutationID'];

		$mysqli->query("UPDATE activitystafff SET actName= '$actName', Sdurarion='$Sdurarion', permutationID='$permutationID' WHERE Sactivity_ID=$Sactivity_ID")or die($mysqli->error);

		$_SESSION['message'] = "Record has been updated!";
		$_SESSION['msg_type'] = "warning";

		header("location: addactStaff.php");

}