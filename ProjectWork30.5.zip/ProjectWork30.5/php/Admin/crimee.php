<!DOCTYPE html>
<html>
<head>
	<title> Successfully</title>
</head>
<body>

</body>
</html>


<?php
	include_once 'config.php';



	$crimeName = $_POST['crimeName'];
	$crimeType = $_POST['crimeType'];
	$crimeTime = $_POST['crimeTime'];


	$sql = "INSERT INTO crime (crimeName, crimeType, crimeTime) VALUES ('$crimeName', '$crimeType', '$crimeTime')";

//echo "$sql";

	mysqli_query($link, $sql);


	header("location: crimelist.php");
?>

<!-- see results <a href="#">results</a> <br> <br> 

-->

