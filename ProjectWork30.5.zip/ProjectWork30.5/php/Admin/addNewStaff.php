<!-- 

        <h3>Staff Information</h3>
<?php require_once 'process.php'; ?>


<?php

if(isset($_SESSION['message'])): ?>

  <div class="alert alert-<?=$_SESSION['msg_type']?>">
 
    <?php
    echo $_SESSION['message'];
    unset($_SESSION ['message']);
    ?>

</div>
<?php endif ?>

    <div class="container">

<?php
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));
$result = $mysqli ->query("SELECT * FROM staff ORDER BY staff_id ASC") or die($mysqli->error);
 //pre_r($result);
?>

 <table      
        
        width="1500" 
        height= "300"
        border="1" 
        cellpadding="1"
        height="10">
  <div class="subcontainer11">

      <thead >
        <tr style="
                  font-size: 16px; 
                  width: 300px; 
                  color: #ff9900;
                  color: #fff;
                  height: 40px;
                  text-align: center;
                  height: 60px;
                  padding-bottom: 100px;
                  "> 
          <th style="
                  width: 60px; 
                  height: 10px;
                  ">ID</th>
          <th>First Name</th>
          <th>Last  Name</th>
          <th>Date of Birth</th>
          <th>Status</th>
          <th>Phone number</th>
          <th>Address</th>
          <th>Educ Level</th>
          <th>Gender</th>
          <th style="
                  width: 90px; 
                  height: 20px;
                  line-height: 40px;
                  ">Title</th>
          <th>Nationality</th>
          <th>Created</th>
          <th colspan="2">Action</th>
        </tr>
      </thead>
    <?php 
      while ($row = $result->fetch_assoc()):?>
        <tr>
          <td><?php echo $row['staff_id']; ?></td>
          <td><?php echo $row['firstname']; ?></td>
          <td><?php echo $row['lastname']; ?></td>
          <td><?php echo $row['dob']; ?></td>
          <td><?php echo $row['status']; ?></td>
          <td><?php echo $row['phonenumber']; ?></td>
          <td><?php echo $row['address']; ?></td>
          <td><?php echo $row['educlevel']; ?></td>
          <td><?php echo $row['gender']; ?></td>
          <td><?php echo $row['title']; ?></td>
          <td><?php echo $row['nationality']; ?></td>
          <td><?php echo $row['created_at']; ?></td>
          <td>
            <a href="addNewStaff.php?edit=<?php echo $row['staff_id']; ?>" 
              class="btn-info">Edit</a>
              <a href="process.php?delete=<?php echo $row['staff_id']; ?>"
                class="btn-danger">Delete</a>
          </td>
        </tr>

      <?php endwhile;  ?>
  </table>
</div>

<div class="row justify-content-center">
  <form action="process.php" method="POST">

    <input type="hidden"name ="staff_id" value="<?php echo $staff_id; ?>">
    <div class="input-group">
    <div class="form-group">
    <label> First Name </label>
    <input type="text" name="firstname" class="form-control"
    value="<?php echo $firstname; ?>" placeholder="Enter firstname" >
    <span class ="help-block"></span>
    </div>

    
    <div class="form-group">
    <label> Last Name </label>
    <input type="text" name="lastname" class="form-control"
    value="<?php echo $lastname; ?>" placeholder="Enter last name" >
    </div>

    <div class="form-group">
    <label> Date of Birth </label>
    <input type="date" name="dob"  class="form-control" 
    value="<?php echo $dob; ?>" placeholder="Enter dob" >

    </div>

    <div class="form-group">
    <label> Status </label>
    <input type="text" name="status"  class="form-control" 
    value="<?php echo $status; ?>" placeholder="Enter status" >

    </div>

    <div class="form-group">
    <label> Phone Number </label>
    <input type="text" name="phonenumber"  class="form-control" 
    value="<?php echo $phonenumber; ?>" placeholder="Enter phonenumber" >

    </div>

    <div class="form-group">
    <label> Address </label>
    <input type="text" name="address"  class="form-control" 
    value="<?php echo $address; ?>" placeholder="Enter address" >
    </div>

    <div class="form-group">
    <label> Education Level </label>
    <input type="text" name="educlevel"  class="form-control" 
     value="<?php echo $educlevel; ?>" placeholder="Enter Education Level" >
   
    </div>

    <div class="form-group">
    <label> Gender </label>
    <input type="text" name="gender"  class="form-control" 
    value="<?php echo $gender; ?>" placeholder="Enter gender" > 
    </div>

    <div class="form-group">
    <label> Title </label>
    <input type="text" name="title"  class="form-control" 
    value="<?php echo $title; ?>" placeholder="Enter title" > 
    </div>

    <div class="form-group">
    <label> Nationality </label>
    <input type="text" name="nationality"  class="form-control" 
    value="<?php echo $nationality; ?>" placeholder="Enter nationality" > 
    </div>


    <div class="form-group">
      <?php 
        if ($update == true):
      ?>

    <button type="submit" class="btn btn-info" name="update">Update</button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary" name="save">Save</button>
    <?php endif; ?>
    </div>

            </form>
          </div>
          <div class="input-group">
           <div class="nav">
          </div>
            <div class="form-group">
          </div>              
      </form>
    </div>
    </div>  
  </div>
</div>

            <div id="subcontainer4">
            
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
          </div>
        </div>
      </div>

            </div>
          </section>
       </body> 
    </head>
  </html> 


 -->



 <!DOCTYPE html>
<html>
<head>
<title>Prison MUNZENZE</title>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/staff/addNewStaff.css">
</head>
         <style>
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 20px;  
  border: none;
  outline: none;
  color: #887558;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #29441c;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
    float: none;
    color: #b7c1b2;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
    background-color: #0c0c0c;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}


/*Form for Sign Up | Sign in*/
.header {
  width: 30%;
  margin: 50px auto 0px;
  color: white;
  background: #999999; 
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
form, .content {
  width: 30%;
  margin: 0px auto;
  padding: 20px;
  border: 1px solid #B0C4DE;
  background: white;
  border-radius: 10px 10px 10px 10px;
  background-color: rgba(52, 73, 94, 0.7);

}
.input-group {
  margin: 10px 0px 10px 0px;
}

.input-group label {
  display: block;
  text-align: left;
  margin: 3px;
  color: aliceblue;
  padding: 6px;
}
.input-group input {
  height: 30px;
  width: 93%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;

}
.btn {
  padding: 10px;
  font-size: 15px;
  color: white;
  background: #5F9EA0;
  border: none;
  border-radius: 5px;
  width: 150px;
  margin-right: 310px;
  margin-top: 17px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #a94442; 
  color: #a94442; 
  background: #f2dede; 
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #dff0d8; 
  border: 1px solid #3c763d;
  margin-bottom: 20px;
}
</style>

<body>

<header>
</header>

<section class="container">
  <div id="subcontainer1">
    <h2> Dashboard</h2>
    <p>Logout</p>
  </div>

   <div id="subcontainer2">
    <h1>.</h1>
        <h1>The Ministry of Interior and Department of National Security. </h1>
            <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
              <h3>Correction & rehabilitation centre</h3>
  </div>

   <div id="subcontainer3">
    <h1>User Name</h1>
  </div>

   <div id="subcontainer4">
    <h1>Dashboard</h1>

            <div class="navv">

                <div class="dropdown">
    <button class="dropbtn">Prisoner Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addNewPrisoner1.php">Add new prisoner</a>
      <a href="addNewPrisoner.php">View prisoner</a>
      <a href="addNewPrisoner.php">Update prisoner</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Cell Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="cell.php">Add a new cell</a>
      <a href="cellList.php">View cell</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Staff Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addnewstaff2.php">add new  staff</a>
      <a href="stafflist.php">View View staff</a>
      <a href="addnewstaff.php">Update staff</a>
    </div>
  </div> 
                     

                <div class="dropdown">
    <button class="dropbtn">User Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="../index.php">add a new user</a>
      <a href="userlist.php">View users</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Crime Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="crime.php">add a new crime</a>
      <a href="crimelist.php">View crime</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Block Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="block.php">add a new block</a>
      <a href="blocklist.php">View block</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Next Skin Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addskin1.php">Add new Next Skin</a>
      <a href="skinlist.php">View Next Skin</a>
      <a href="addskin.php">Update Next Skin</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Prisoner Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactPrisoner1.php">Add Activity</a>
      <a href="prisoneractList.php">View Activity</a>
      <a href="addactPrisoner.php">Update Activity</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Staff Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactStaff1.php">Add Activity</a>
      <a href="StaffactList.php">View Activity</a>
      <a href="addactStaff.php">Update Activity</a>
    </div>
  </div> 

  </div>

   <div id="subcontainer5">
    <h1>Staff Information</h1>
  </div>

   <div id="subcontainer6">
        <h3>Staff Information</h3>
<?php require_once 'process.php'; ?>


<?php

if(isset($_SESSION['message'])): ?>

  <div class="alert alert-<?=$_SESSION['msg_type']?>">
 
    <?php
    echo $_SESSION['message'];
    unset($_SESSION ['message']);
    ?>

</div>
<?php endif ?>

    <div class="container">

<?php
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));
$result = $mysqli ->query("SELECT * FROM staff ORDER BY staff_id ASC") or die($mysqli->error);
 //pre_r($result);
?>

 <table          
        height= "300"
        border="1" 
        cellpadding="1"
        height="10">
  <div class="subcontainer11">

      <thead >
        <tr style="
                  font-size: 16px; 
                  width: 300px; 
                  color: #ff9900;
                  color: #fff;
                  height: 40px;
                  text-align: center;
                  height: 60px;
                  padding-bottom: 100px;
                  "> 
          <th style="
                  width: 50px; 
                  height: 3px;

                  ">#</th>
          <th
          style="width: 120px;"
          >First Name</th>
          <th
          style="width: 120px;"
          >Last  Name</th>

          <th
          style="width: 120px;"
          >Date of Birth</th>

          <th
          style="width: 90px;"
          >Status</th>

          <th
          style="width: 150px;"
          >Phone number</th>
          <th
          style="width: 120px;"
          >Address</th>
          <th
          style="width: 90px;"
          >Educ Level</th>

          <th
          style="width: 90px;"
          >Gender</th>

          <th
          style="width: 90px;"
          >Title</th>

          <th
          style="width: 90px;"
          >Nationality</th>

          <th
          style="width: 140px;"
          >Created</th>
          <th 
          style="width: 1000px;"
          colspan="2">Action</th>
        </tr>
      </thead>
    <?php 
      while ($row = $result->fetch_assoc()):?>
        <tr>
          <td><?php echo $row['staff_id']; ?></td>
          <td><?php echo $row['firstname']; ?></td>
          <td><?php echo $row['lastname']; ?></td>
          <td><?php echo $row['dob']; ?></td>
          <td><?php echo $row['status']; ?></td>
          <td><?php echo $row['phonenumber']; ?></td>
          <td><?php echo $row['address']; ?></td>
          <td><?php echo $row['educlevel']; ?></td>
          <td><?php echo $row['gender']; ?></td>
          <td><?php echo $row['title']; ?></td>
          <td><?php echo $row['nationality']; ?></td>
          <td><?php echo $row['created_at']; ?></td>
          <td>
            <a href="addNewStaff.php?edit=<?php echo $row['staff_id']; ?>" 
              class="btn-info">Edit</a>
              <a href="process.php?delete=<?php echo $row['staff_id']; ?>"
                class="btn-danger">Delete</a>
          </td>
        </tr>

      <?php endwhile;  ?>
  </table>
</div>


<div class="row justify-content-center">
  <form action="process.php" method="POST">

    <div class="input-group">
    <div class="form-group">
    <label> First Name </label>
    <input type="text" name="firstname" class="form-control"
    value="<?php echo $firstname; ?>" placeholder="Enter First Name" required>
    <span class ="help-block"></span>
    </div>

    
    <div class="form-group">
    <label> Last Name </label>
    <input type="text" name="lastname" class="form-control"
    value="<?php echo $lastname; ?>" placeholder="Enter Last Name" required>
    
    </div>

    <div class="form-group">
    <label> Date of Birth </label>
    <input type="date" name="dob"  class="form-control"
    value="<?php echo $dob; ?>" placeholder="Enter dob" required>
    </div>

    <div class="form-group">
     <label for="status"> Choose a status: </label>
    <select name="status" style="width: -webkit-fill-available;
    height: 77px; font-size: inherit;">
      <option value="Undefined">Undefined</option>
      <option value="Married">Married</option>
      <option value="Single">Single</option>
      <option value="divorced">divorced</option>
      <option value="Compliacted">Compliacted</option>
      <option value="None">None</option>
    </select>
    </div>

    <div class="form-group">
    <label> Phone Number </label>
    <input type="text" name="phonenumber"  class="form-control"
    value="<?php echo $phonenumber; ?>" placeholder="Enter Phone number" required> 
    </div>

    <div class="form-group">
    <label> Address </label>
    <input type="text" name="address"  class="form-control"
    value="<?php echo $address; ?>" placeholder="Enter Address" required> 
    </div>

    <div class="form-group">
    <label> Education Level </label>
    <input type="text" name="educlevel"  class="form-control"
    value="<?php echo $educlevel; ?>" placeholder="Enter education level" required> 
    </div>

    <div class="form-group">
    <label> Gender </label>
    <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="female") echo "checked";?>
    value="female">Female

    <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="male") echo "checked";?>
    value="male">Male

     <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="other") echo "checked";?>
    value="other">Other

    <div class="form-group">
     <label for="title"> Choose a Title: </label>
    <select name="title" style="width: -webkit-fill-available;
    height: 77px; font-size: inherit;">
      <option value="jailor">Jailor</option>
      <option value="Administrator">Administrator</option>
    </select>
    </div>

    <div class="form-group">
    <label> Nationality </label>
    <input type="text" name="nationality"  class="form-control"
    value="<?php echo $nationality; ?>" placeholder="Enter Nationality" required> 
    </div>


    <div class="form-group">
      <?php 
        if ($update == true):
      ?>

    <button type="submit" class="btn btn-info" name="update">Update</button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary" name="save">Save</button>
    <?php endif; ?>
    </div>

  </form>
</div>


          <div class="input-group">

           <div class="nav">

          </div>
            <div class="form-group">

          </div>              
      </form>
    </div>
    </div>  
  </div>
</div></div>
        <div id="subcontainer7">
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>

</section>

              <a href="../../pages/about.php" style="margin-left: 1490px; text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">|| Logout ||</a></li>
            </ul>

