<!DOCTYPE html>
<html>
<head>
	<title> Successfully</title>
</head>
<body>

</body>
</html>


<?php
	include_once 'config.php';



	$name = $_POST['name'];

	$sql = "INSERT INTO block (name) VALUES ('$name')";

//echo "$sql";

	mysqli_query($link, $sql);


	header("location: blocklist.php");
?>

<!-- see results <a href="#">results</a> <br> <br> 

-->

