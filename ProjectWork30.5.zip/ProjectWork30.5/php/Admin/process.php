<?php


session_start();
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));

$staff_id = 0;
$update = false;

$firstname = '';
$lastname = '';
$dob = '';
$status = '';
$phonenumber = '';
$address = '';
$educlevel = '';
$gender = '';
$title = '';
$nationality = '';


if (isset($_POST['save'])){
	$staff_id = $_POST['staff_id'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$dob = $_POST['dob'];
	$status = $_POST['status'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$educlevel = $_POST['educlevel'];
	$gender = $_POST['gender'];
	$title = $_POST['title'];
	$nationality = $_POST['nationality'];


	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";



	$mysqli->query("INSERT INTO staff (firstname, lastname, dob, status, phonenumber, address, educlevel, gender, title, nationality) VALUES('$firstname', '$lastname', '$dob', '$status', '$phonenumber', '$address', '$educlevel', '$gender', '$title', '$nationality') ") or 
	die($mysqli->error);

	header("location: addNewStaff.php");
}

if (isset($_GET['delete'])){
	$staff_id = $_GET['delete'];
	$mysqli->query("DELETE FROM staff WHERE staff_id=$staff_id") or die($mysqli->error());



	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";

header("location: addNewStaff.php");

}

if (isset($_GET['edit'])){
	$staff_id = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM staff WHERE staff_id=$staff_id") or die($mysqli->error());
	// if (count($result) == 1 ){
	if (mysqli_num_rows($result) == 1 ){
		$row = $result->fetch_array();

	$firstname = $row['firstname'];
	$lastname = $row['lastname'];
	$dob = $row['dob'];
	$status = $row['status'];
	$phonenumber = $row['phonenumber'];
	$address = $row['address'];
	$educlevel = $row['educlevel'];
	$gender = $row['gender'];
	$title = $row['title'];
	$nationality = $row['nationality'];

	}

}

if (isset($_POST['update'])){
	$staff_id = $_POST['staff_id'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$dob = $_POST['dob'];
	$status = $_POST['status'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$educlevel = $_POST['educlevel'];
	$gender = $_POST['gender'];
	$title = $_POST['title'];
	$nationality = $_POST['nationality'];

		$mysqli->query("UPDATE staff SET firstname='$firstname', lastname='$lastname', dob='$dob', status='$status', phonenumber ='$phonenumber', address='$address', educlevel='$educlevel', gender='$gender', title='$title', nationality='$nationality' WHERE staff_id=$staff_id")or die($mysqli->error);

		$_SESSION['message'] = "Record has been updated!";
		$_SESSION['msg_type'] = "warning";

		header('location: addNewStaff.php');

}