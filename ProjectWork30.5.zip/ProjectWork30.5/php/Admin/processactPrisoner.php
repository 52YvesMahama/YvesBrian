<?php


session_start();
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));

$Pactivity_ID = 0;
$update = false;

$actName = '';
$Pdurarion = '';
$permutationID = '';

if (isset($_POST['save'])){
	$Pactivity_ID = $_POST['Pactivity_ID'];
	$actName = $_POST['actName'];
	$Pdurarion = $_POST['Pdurarion'];
	$permutationID = $_POST['permutationID'];


	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";

	$mysqli->query("INSERT INTO activityprisoner (actName, staff_id, Pdurarion, permutationID) VALUES('$actName', '$Pdurarion', '$permutationID') ") or 
	die($mysqli->error);
		header("location: addactPrisoner.php");
}


if (isset($_GET['delete'])){
	$Pactivity_ID = $_GET['delete'];
	$mysqli->query("DELETE FROM activityprisoner WHERE Pactivity_ID=$Pactivity_ID") or die($mysqli->error());



	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";

		header("location: addactPrisoner.php");

}

if (isset($_GET['edit'])){
	$Pactivity_ID = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM activityprisoner WHERE Pactivity_ID=$Pactivity_ID") or die($mysqli->error());
	// if (count($result) == 1 ){
	if (mysqli_num_rows($result) == 1 ){
		$row = $result->fetch_array();

	
	// $activity_ID = $row['activity_ID'];
	$actName = $row['actName'];
	$Pdurarion = $row['Pdurarion'];
	$permutationID = $row['permutationID'];
	}

}

if (isset($_POST['update'])){
	$Pactivity_ID = $_POST['Pactivity_ID'];
	$actName = $_POST['actName'];
	$Pdurarion = $_POST['Pdurarion'];
	$permutationID = $_POST['permutationID'];

		$mysqli->query("UPDATE activityprisoner SET actName= '$actName', Pdurarion='$Pdurarion', permutationID='$permutationID' WHERE Pactivity_ID=$Pactivity_ID")or die($mysqli->error);

		$_SESSION['message'] = "Record has been updated!";
		$_SESSION['msg_type'] = "warning";

		header("location: addactPrisoner.php");

}