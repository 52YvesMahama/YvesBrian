<?php


session_start();
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));

$skinID = 0;
$update = false;

$skinIDNumber = '';
$firstname = '';
$lastname = '';
$phonenumber = '';
$address = '';
$gender = '';
$relation = '';
$prisonerID = '';




if (isset($_POST['save'])){

	$skinID = $_POST['skinID'];
	$skinIDNumber = $_POST['skinIDNumber'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$gender = $_POST['gender'];
	$relation = $_POST['relation'];
	$prisonerID = $_POST['prisonerID'];


	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";

	$mysqli->query("INSERT INTO skin (skinIDNumber, firstname, lastname, phonenumber, address, gender, relation, prisonerID) VALUES('$skinIDNumber', '$firstname',  '$lastname', '$phonenumber', '$address', '$gender', '$relation', '$prisonerID') ") or 
	die($mysqli->error);
		header("location: addskin.php");
}


if (isset($_GET['delete'])){
	$skinID = $_GET['delete'];
	$mysqli->query("DELETE FROM skin WHERE skinID=$skinID") or die($mysqli->error());



	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";

		header("location: addskin.php");

}

if (isset($_GET['edit'])){
	$skinID = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM skin WHERE skinID=$skinID") or die($mysqli->error());
	// if (count($result) == 1 ){
	if (mysqli_num_rows($result) == 1 ){
		$row = $result->fetch_array();

	
	$skinIDNumber = $row['skinIDNumber'];
	$firstname = $row['firstname'];
	$lastname = $row['lastname'];
	$phonenumber = $row['phonenumber'];
	$address = $row['address'];
	$gender = $row['gender'];
	$relation = $row['relation'];
	$prisonerID = $row['prisonerID'];
	}

}

if (isset($_POST['update'])){
	$skinID = $_POST['skinID'];
	$skinIDNumber = $_POST['skinIDNumber'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$gender = $_POST['gender'];
	$relation = $_POST['relation'];
	$prisonerID = $_POST['prisonerID'];

		$mysqli->query("UPDATE skin SET skinIDNumber= '$skinIDNumber', firstname='$firstname', lastname='$lastname', phonenumber ='$phonenumber', address='$address', gender='$gender', relation='$relation', prisonerID='$prisonerID' WHERE skinID=$skinID")or die($mysqli->error);

		$_SESSION['message'] = "Record has been updated!";
		$_SESSION['msg_type'] = "warning";

		header("location: addskin.php");

}