<!DOCTYPE html>
<html>
<head>
	<title> Successfully</title>
</head>
<body>

</body>
</html>


<?php
	include_once 'config.php';



	$cellID = $_POST['cellID'];
	$cellName = $_POST['cellName'];
	$BlockID = $_POST['BlockID'];


	$sql = "INSERT INTO cell (cellName, BlockID) VALUES ('$cellName', '$BlockID')";

//echo "$sql";

	mysqli_query($link, $sql);


	header("location: celllist.php");
?>

<!-- see results <a href="#">results</a> <br> <br> 

-->

