<!-- 
  <?php require_once 'processPrison.php'; ?>
-->

 <!DOCTYPE html>
<html>
<head>
  <title>Prison MUNZENZE</title>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/prisoner/addPrisoner.css">
</head>
         <style>
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 20px;  
  border: none;
  outline: none;
  color: #887558;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #29441c;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
    float: none;
    color: #b7c1b2;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
    background-color: #0c0c0c;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}


/*Form for Sign Up | Sign in*/
.header {
  width: 30%;
  margin: 50px auto 0px;
  color: white;
  background: #999999; 
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
form, .content {
  width: 30%;
  margin: 0px auto;
  padding: 20px;
  border: 1px solid #B0C4DE;
  background: white;
  border-radius: 10px 10px 10px 10px;
  background-color: rgba(52, 73, 94, 0.7);

}
.input-group {
  margin: 10px 0px 10px 0px;
}

.input-group label {
  display: block;
  text-align: left;
  margin: 3px;
  color: aliceblue;
  padding: 6px;
}
.input-group input {
  height: 30px;
  width: 93%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;

}
.btn {
  padding: 10px;
  font-size: 15px;
  color: white;
  background: #5F9EA0;
  border: none;
  border-radius: 5px;
  width: 150px;
  margin-right: 310px;
  margin-top: 17px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #a94442; 
  color: #a94442; 
  background: #f2dede; 
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #dff0d8; 
  border: 1px solid #3c763d;
  margin-bottom: 20px;
}
</style>

<body>

<header>
</header>

<section class="container">
  <div id="subcontainer1">
    <h2> Dashboard</h2>
    <p>Logout</p>
  </div>

   <div id="subcontainer2">
    <h1>.</h1>
        <h1>The Ministry of Interior and Department of National Security. </h1>
            <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
              <h3>Correction & rehabilitation centre</h3>
  </div>

   <div id="subcontainer3">
    <h1>User Name</h1>
  </div>

   <div id="subcontainer4">
    <h1>Dashboard</h1>

            <div class="navv">

                <div class="dropdown">
    <button class="dropbtn">Prisoner Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addNewPrisoner1.php">Add new prisoner</a>
      <a href="addNewPrisoner.php">View prisoner</a>
      <a href="addNewPrisoner.php">Update prisoner</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Cell Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="cell.php">Add a new cell</a>
      <a href="cellList.php">View cell</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Staff Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addnewstaff2.php">add new  staff</a>
      <a href="stafflist.php">View View staff</a>
      <a href="addnewstaff.php">Update staff</a>
    </div>
  </div> 
                     

                <div class="dropdown">
    <button class="dropbtn">User Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="../index.php">add a new user</a>
      <a href="userlist.php">View users</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Crime Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="crime.php">add a new crime</a>
      <a href="crimelist.php">View crime</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Block Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="block.php">add a new block</a>
      <a href="blocklist.php">View block</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Next Skin Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addskin1.php">Add new Next Skin</a>
      <a href="skinlist.php">View Next Skin</a>
      <a href="addskin.php">Update Next Skin</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Prisoner Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactPrisoner1.php">Add Activity</a>
      <a href="prisoneractList.php">View Activity</a>
      <a href="addactPrisoner.php">Update Activity</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Staff Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactStaff1.php">Add Activity</a>
      <a href="StaffactList.php">View Activity</a>
      <a href="addactStaff.php">Update Activity</a>
    </div>
  </div> 

  </div>

   <div id="subcontainer5">
    <h1>Staff Information</h1>
  </div>

   <div id="subcontainer6">
        <h3>Prisoner Information</h3>
<?php require_once 'processPrison.php'; ?>


<?php

if(isset($_SESSION['message'])): ?>

  <div class="alert alert-<?=$_SESSION['msg_type']?>">
 
    <?php
    echo $_SESSION['message'];
    unset($_SESSION ['message']);
    ?>

</div>
<?php endif ?>

    <div class="container">

<?php
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));
$result = $mysqli ->query("SELECT * FROM prisoner ORDER BY prisonerIDD ASC") or die($mysqli->error);
 //pre_r($result);
?>

 <table      
        
        height= "300"
        border="1" 
        cellpadding="1"
        height="10">
  <div class="subcontainer11">

      <thead >
        <tr style="
                  font-size: 16px; 
                  width: 300px; 
                  color: #ff9900;
                  color: #fff;
                  height: 40px;
                  text-align: center;
                  height: 60px;
                  padding-bottom: 100px;
                  "> 
          <th style="
                  width: 50px; 
                  height: 3px;

                  ">#</th>
          <th
          style="width: 90px;"
          >Prisoner ID</th>
          <th
          style="width: 120px;"
          >Block ID</th>
          <th
          style="width: 120px;"
          >Cell ID</th>
          <th
          style="width: 150px;"
          >Crime ID</th>
          <th 
          style="width: 50px;"
          colspan="2">Action</th>
        </tr>
      </thead>
    <?php 
      while ($row = $result->fetch_assoc()):?>
        <tr>
          <td><?php echo $row['prisonerIDD']; ?></td>
          <td><?php echo $row['prisonerID']; ?></td>
          <td><?php echo $row['BlockID']; ?></td>
          <td><?php echo $row['cellID']; ?></td>
          <td><?php echo $row['crimeID']; ?></td>
          <td>
            <a href="addPrisoner.php?edit=<?php echo $row['prisonerIDD']; ?>" 
              class="btn-info">Edit</a>
              <a href="process/processPrisoner.php?delete=<?php echo $row['prisonerIDD']; ?>"
                class="btn-danger">Delete</a>
          </td>
        </tr>

      <?php endwhile;  ?>
  </table>
</div>

<div class="row justify-content-center">
  <form action="process/processPrisoner.php" method="POST">

    <input type="hidden"name ="prisonerIDD" value="<?php echo $prisonerIDD; ?>">
    <div class="input-group">

    <div class="input-group">
    <div class="form-group">
    <label> Prisoner ID </label>
    <input type="text" name="prisonerID" class="form-control"
    value="<?php echo $prisonerID; ?>" placeholder="Enter Prisoner ID" required>
    <span class ="help-block"></span>
    </div>

    <div class="input-group">
    <div class="input-group">
    <div class="form-group">
    <label> Block ID </label>
    <input type="text" name="BlockID" class="form-control"
    value="<?php echo $BlockID; ?>" placeholder="Enter  Block ID" required>
    <span class ="help-block"></span>
    </div>

    
    <div class="form-group">
    <label> Cell ID </label>
    <input type="text" name="cellID" class="form-control"
    value="<?php echo $cellID; ?>" placeholder="Enter Cell ID " required>
    </div>

    <div class="form-group">
    <label> Crime ID </label>
    <input type="text" name="crimeID"  class="form-control"
    value="<?php echo $crimeID; ?>" placeholder="Enter Crime ID " required> 
    </div>

    <div class="form-group">
      <?php 
        if ($update == true):
      ?>

    <button type="submit" class="btn btn-info" name="update">Update</button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary" name="save">Save</button>
    <?php endif; ?>
    </div>

  </form>
</div>


          <div class="input-group">

           <div class="nav">

          </div>
            <div class="form-group">

          </div>              
      </form>
    </div>
    </div>  
  </div>
</div>  </div>


        <div id="subcontainer7">
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>

</section>

              <a href="../../pages/about.php" style="margin-left: 1490px; text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">|| Logout ||</a></li>
            </ul>

