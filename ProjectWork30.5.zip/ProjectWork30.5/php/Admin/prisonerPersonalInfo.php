<?php 

include('config.php');
// check Get request ID perameter
if(isset($_GET['prisonerID'])){

	$prisonerID = mysqli_real_escape_string($link, $GET['prisonerID']);

	// make sql
	$sql = "SELECT * FROM inmates where prisonerID = $prisonerID";

	// get the query

	$result = mysqli_query($link, $sql);

	// fetch results
	$inmates = mysqli_fetch_assoc($result);

	mysqli_free_result($result);
	mysqli_close($link);

	print_r($inmates);
}

?>

<!DOCTYPE html>
<html>

<div class="container center">

<?php if($inmates): ?>
	<h4><?php echo htmlspecialchars($inmates['prisonerID']); ?></h4>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['IDNumber']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['firstname']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['lastname']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['phonenumber']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['address']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['placeofbirth']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['dob']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['crimeID']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['cellID']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['status']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['educlevel']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['gender']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['nationality']); ?></p>
	<p>Creatd by: <?php echo htmlspecialchars($inmates['created_at']); ?></p>
<?php else: ?>

<?php endif; ?>
</div>
<h2>Details infos for a particular Prisoner</h2>


</html>