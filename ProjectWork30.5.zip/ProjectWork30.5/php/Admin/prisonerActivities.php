<!DOCTYPE html>
<html>
<head>
      <title>Prison MUNZENZE</title>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/prisoner/activityPrisonerL.css">
</head>
         <style>



.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 20px;  
  border: none;
  outline: none;
  color: #887558;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #29441c;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
    float: none;
    color: #b7c1b2;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
    background-color: #0c0c0c;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>

<body>

<header>
</header>

<section class="container">
  <div id="subcontainer1">
    <h2> Dashboard</h2>
    <p>Logout</p>
  </div>

   <div id="subcontainer2">
    <h1>home</h1>
  </div>

   <div id="subcontainer3">
    <h1>User Name</h1>
  </div>

   <div id="subcontainer4">
    <h1>Dashboard</h1>

            <div class="navv">

                <div class="dropdown">
    <button class="dropbtn">Prisoner Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addNewPrisoner1.php">Add new prisoner</a>
      <a href="addNewPrisoner.php">View prisoner</a>
      <a href="addNewPrisoner.php">Update prisoner</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Cell Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="cell.php">Add a new cell</a>
      <a href="cellList.php">View cell</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Staff Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addnewstaff2.php">add new  staff</a>
      <a href="stafflist.php">View View staff</a>
      <a href="addnewstaff.php">Update staff</a>
    </div>
  </div> 
                     

                <div class="dropdown">
    <button class="dropbtn">User Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="../index.php">add a new user</a>
      <a href="userlist.php">View users</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Crime Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="crime.php">add a new crime</a>
      <a href="crimelist.php">View crime</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Block Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="block.php">add a new block</a>
      <a href="blocklist.php">View block</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Next Skin Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addskin1.php">Add new Next Skin</a>
      <a href="skinlist.php">View Next Skin</a>
      <a href="addskin.php">Update Next Skin</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Prisoner Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactPrisoner1.php">Add Activity</a>
      <a href="prisoneractList.php">View Activity</a>
      <a href="addactPrisoner.php">Update Activity</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Staff Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactStaff1.php">Add Activity</a>
      <a href="StaffactList.php">View Activity</a>
      <a href="addactStaff.php">Update Activity</a>
    </div>
  </div> 

  </div>

   <div id="subcontainer5">
    <h1>Staff Information</h1>
  </div>

   <div id="subcontainer6">
        <h3>Prisoner Activity Information</h3>
<table >
        <tr bgcolor='#ff9900'

        > 
     
            <td 
            style="width: 200px;"
            > Transaction ID</td> 
            <td
            style="width: 250px;"
            >Prisoner ID</td> 
            <td
            style="width: 250px;"
            >Prisoner Activity ID</td> 
            <td
            style="width: 250px;"
            >Staff on Duty ID</td> 
</tr>

<?php

// make connection
$link=mysqli_connect('localhost','root', '');

// select db
mysqli_select_db($link,'prison');

$sql="SELECT * FROM ttprisoner2";

$records=mysqli_query($link,$sql);

while ($row=mysqli_fetch_assoc($records)){

  echo "<tr>";
  
            echo "<td>".$row['ttprisoner2ID']."</td>"; 
            echo "<td>".$row['prisonerIDD']."</td>"; 
            echo "<td>".$row['Pactivity_ID']."</td>"; 
            echo "<td>".$row['permutationID']."</td>"; 
  echo "</tr>";
} // end while

?>
</table>
   </div>

        <div id="subcontainer7">
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>

</section>

              <a href="../../pages/about.php" style="margin-left: 1490px; text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">|| Logout ||</a></li>
            </ul>

