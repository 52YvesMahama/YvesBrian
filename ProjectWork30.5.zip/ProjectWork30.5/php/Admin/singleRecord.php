<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "prison");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM inmates";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
            echo "<tr>";
                echo "<th>prisonerID</th>";
                echo "<th>IDNumber</th>";
                echo "<th>firstname</th>";
                echo "<th>lastname</th>";
                echo "<th>phonenumber</th>";
                echo "<th>address</th>";
                echo "<th>placeofbirth</th>";
                echo "<th>dob</th>";
                echo "<th>crimeID</th>";
                echo "<th>cellID</th>";
                echo "<th>status</th>";
                echo "<th>educlevel</th>";
                echo "<th>gender</th>";
                echo "<th>nationality</th>";
                echo "<th>created_at</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['prisonerID'] . "</td>";
                echo "<td>" . $row['IDNumber'] . "</td>";
                echo "<td>" . $row['firstname'] . "</td>";
                echo "<td>" . $row['lastname'] . "</td>";
                echo "<td>" . $row['phonenumber'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
                echo "<td>" . $row['placeofbirth'] . "</td>";
                echo "<td>" . $row['dob'] . "</td>";
                echo "<td>" . $row['crimeID'] . "</td>";
                echo "<td>" . $row['cellID'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td>" . $row['educlevel'] . "</td>";
                echo "<td>" . $row['gender'] . "</td>";
                echo "<td>" . $row['nationality'] . "</td>";
                echo "<td>" . $row['created_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>