<!-- 
<!DOCTYPE html>
  <html>
    <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">  
    </head>
        <link rel="stylesheet" type="text/css" href="../../css/css.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssY.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssResults3.css">




         
<title>Prison Munzenze</title>
          <body>
          <section class="container">
              <div id="subcontainer1">
                    <center><h1>The Ministry of Interior and Department of National Security. </h1></center>
                      <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
                            <h3>Correction & rehabilitation centre</h3>
                </div>
                <div id="subcontainer2">
                   <div class="nav">
                      <ul>
                        <li class="home"><a href="../../index.html">Home</a></li>
                        <li class="contact"><a href="../../pages/contact.php">Contact</a></li>
                        <li class="about"><a href="../../pages/about.php">About Us</a></li>
                        <li class="about"><a class="active" href="Login.php" style="margin-left: 400px; width: 100px;">Logout</a></li>
                      </ul>
                   </div>

                <div id="subcontainer3">
                  <body>

    <div class="container">
    <div class="wrapper">
    <h2>Administrator Dashord</h2>  Welcome (who logged_in)
  </div>

        <h3>Add prisoner Information</h3>
<?php require_once 'processSkin.php'; ?>


<?php

if(isset($_SESSION['message'])): ?>

  <div class="alert alert-<?=$_SESSION['msg_type']?>">
 
    <?php
    echo $_SESSION['message'];
    unset($_SESSION ['message']);
    ?>

</div>
<?php endif ?>

    <div class="container">

<?php
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));
$result = $mysqli ->query("SELECT * FROM skin ORDER BY skinID ASC") or die($mysqli->error);
 //pre_r($result);
?>


<?php 

  function pre_r($array){
    echo '<pre>';
    print_r($array);
    echo '</pre>';
  }

?>


<div class="row justify-content-center">
  <form action="processSkin.php" method="POST">

    <div class="input-group">
    <div class="form-group">
    <label> ID Number </label>
    <input type="text" name="skinIDNumber" class="form-control"
    value="<?php echo $skinIDNumber; ?>" placeholder="Enter Skin ID Number" required>
    <span class ="help-block"></span>
    </div>

    <div class="input-group">
    <div class="form-group">
    <label> First Name </label>
    <input type="text" name="firstname" class="form-control"
    value="<?php echo $firstname; ?>" placeholder="Enter First Name" required>
    <span class ="help-block"></span>
    </div>

    
    <div class="form-group">
    <label> Last Name </label>
    <input type="text" name="lastname" class="form-control"
    value="<?php echo $lastname; ?>" placeholder="Enter Last Name" required>
    </div>

    <div class="form-group">
    <label> Phone Number </label>
    <input type="text" name="phonenumber"  class="form-control"
    value="<?php echo $phonenumber; ?>" placeholder="Enter Phone number" required> 
    </div>

    <div class="form-group">
    <label> Address </label>
    <input type="text" name="address"  class="form-control"
    value="<?php echo $address; ?>" placeholder="Enter Address" required> 
    </div>

    <div class="form-group">
    <label>Gender</label>
    <input type="text" name="gender"  class="form-control"
    value="<?php echo $gender; ?>" placeholder="Enter gender" required>
    </div>

    <div class="form-group">
    <label> Relation </label>
    <input type="text" name="relation"  class="form-control"
    value="<?php echo $relation; ?>" placeholder="Enter relation" required> 
    </div>

    <div class="form-group">
    <label> Prisoner ID </label>
    <input type="text" name="prisonerID"  class="form-control"
    value="<?php echo $prisonerID; ?>" placeholder="Enter Gender" required> 
    </div>



    <div class="form-group">
      <?php 
        if ($update == true):
      ?>

    <button type="submit" class="btn btn-info" name="update">Update</button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary" name="save">Save</button>
    <?php endif; ?>
    </div>

  </form>
</div>


          <div class="input-group">

           <div class="nav">

          </div>
            <div class="form-group">

          </div>              
      </form>
    </div>
    </div>  
  </div>
</div>

            <div id="subcontainer4">
            
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
          </div>
        </div>
      </div>
        </div>
          </section>
       </body> 
    </head>
  </html> 


 -->


 <!-- 
<!DOCTYPE html>
  <html>
    <head>
  <meta name="viewport" content="width=device-width, initial-scale=1">  
    </head>
        <link rel="stylesheet" type="text/css" href="../../css/css.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssY.css">
        <link rel="stylesheet" type="text/css" href="../../css/cssResults3.css">




         
<title>Prison Munzenze</title>
          <body>
          <section class="container">
              <div id="subcontainer1">
                    <center><h1>The Ministry of Interior and Department of National Security. </h1></center>
                      <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
                            <h3>Correction & rehabilitation centre</h3>
                </div>
                <div id="subcontainer2">
                   <div class="nav">
                      <ul>
                        <li class="home"><a href="../../index.html">Home</a></li>
                        <li class="contact"><a href="../../pages/contact.php">Contact</a></li>
                        <li class="about"><a href="../../pages/about.php">About Us</a></li>
                        <li class="about"><a class="active" href="Login.php" style="margin-left: 400px; width: 100px;">Logout</a></li>
                      </ul>
                   </div>

                <div id="subcontainer3">
                  <body>

    <div class="container">
    <div class="wrapper">
        <div class="header">
  
    <h2>Administrator Dashord</h2>  Welcome (who logged_in)
  </div>

        <h3>Add prisoner Information</h3>
<?php require_once 'processPrison.php'; ?>


<?php

if(isset($_SESSION['message'])): ?>

  <div class="alert alert-<?=$_SESSION['msg_type']?>">
 
    <?php
    echo $_SESSION['message'];
    unset($_SESSION ['message']);
    ?>

</div>
<?php endif ?>

    <div class="container">

<?php
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));
$result = $mysqli ->query("SELECT * FROM inmates ORDER BY prisonerID ASC") or die($mysqli->error);
 //pre_r($result);
?>

<div class="row justify-content-center">
  <form action="processPrison.php" method="POST">

    <div class="input-group">
    <div class="form-group">
    <label> ID Number </label>
    <input type="text" name="IDNumber" class="form-control"
    value="<?php echo $IDNumber; ?>" placeholder="Enter ID Number" required>
    <span class ="help-block"></span>
    </div>

    <div class="input-group">
    <div class="form-group">
    <label> First Name </label>
    <input type="text" name="firstname" class="form-control"
    value="<?php echo $firstname; ?>" placeholder="Enter First Name" required>
    <span class ="help-block"></span>
    </div>

    
    <div class="form-group">
    <label> Last Name </label>
    <input type="text" name="lastname" class="form-control"
    value="<?php echo $lastname; ?>" placeholder="Enter Last Name" required>
    </div>

    <div class="form-group">
    <label> Phone Number </label>
    <input type="text" name="phonenumber"  class="form-control"
    value="<?php echo $phonenumber; ?>" placeholder="Enter Phone number" required> 
    </div>

    <div class="form-group">
    <label> Address </label>
    <input type="text" name="address"  class="form-control"
    value="<?php echo $address; ?>" placeholder="Enter Address" required> 
    </div>

    <div class="form-group">
    <label> Date of Birth </label>
    <input type="date" name="dob"  class="form-control"
    value="<?php echo $dob; ?>" placeholder="Enter dob" required>
    </div>

    <div class="form-group">
    <label> Status </label>
     <label for="status"> Choose a status: </label>
 
    <select name="status">
      <option value="Undefined">Undefined</option>
      <option value="Married">Married</option>
      <option value="Single">Single</option>
      <option value="divorced">divorced</option>
      <option value="Compliacted">Compliacted</option>
      <option value="None">None</option>
    </select>

    </div>


    <div class="form-group">
    <label> Gender </label>
    <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="female") echo "checked";?>
    value="female">Female

    <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="male") echo "checked";?>
    value="male">Male

     <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="other") echo "checked";?>
    value="other">Other
 



    <div class="form-group">
      <?php 
        if ($update == true):
      ?>

    <button type="submit" class="btn btn-info" name="update">Update</button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary" name="save">Save</button>
    <?php endif; ?>
    </div>

  </form>
</div>


          <div class="input-group">

           <div class="nav">

          </div>
            <div class="form-group">

          </div>              
      </form>
    </div>
    </div>  
  </div>
</div>

            <div id="subcontainer4">
            
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
          </div>
        </div>
      </div>

            </div>
          </section>
       </body> 
    </head>
  </html> 


 -->

   <!DOCTYPE html>
<html>
<head>
  <title>Prison MUNZENZE</title>
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
 <link rel="stylesheet" type="text/css" href="css/kin/kin.css">
</head>
         <style>



.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 20px;  
  border: none;
  outline: none;
  color: #887558;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #29441c;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
    float: none;
    color: #b7c1b2;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
    background-color: #0c0c0c;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}


/*Form for Sign Up | Sign in*/
.header {
  width: 30%;
  margin: 50px auto 0px;
  color: white;
  background: #999999; 
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
form, .content {
  width: 30%;
  margin: 0px auto;
  padding: 20px;
  border: 1px solid #B0C4DE;
  background: white;
  border-radius: 10px 10px 10px 10px;
  background-color: rgba(52, 73, 94, 0.7);

}
.input-group {
  margin: 10px 0px 10px 0px;
}

.input-group label {
  display: block;
  text-align: left;
  margin: 3px;
  color: aliceblue;
  padding: 6px;
}
.input-group input {
  height: 30px;
  width: 93%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;

}
.btn {
  padding: 10px;
  font-size: 15px;
  color: white;
  background: #5F9EA0;
  border: none;
  border-radius: 5px;
  width: 150px;
  margin-right: 310px;
  margin-top: 17px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #a94442; 
  color: #a94442; 
  background: #f2dede; 
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #dff0d8; 
  border: 1px solid #3c763d;
  margin-bottom: 20px;
}


</style>

<body>

<header>
</header>

<section class="container">
  <div id="subcontainer1">
    <h2> Dashboard</h2>
    <p>Logout</p>
  </div>

   <div id="subcontainer2">
    <h1>.</h1>
        <h1>The Ministry of Interior and Department of National Security. </h1>
            <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
              <h3>Correction & rehabilitation centre</h3>
  </div>

   <div id="subcontainer3">
    <h1>Yvonne Mahama</h1>
  </div>

   <div id="subcontainer4">
    <h1>Dashboard</h1>

            <div class="navv">

                <div class="dropdown">
    <button class="dropbtn">Prisoner Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addNewPrisoner1.php">Add new prisoner</a>
      <a href="addNewPrisoner.php">View prisoner</a>
      <a href="addNewPrisoner.php">Update prisoner</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Cell Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="cell.php">Add a new cell</a>
      <a href="cellList.php">View cell</a>
    </div>
  </div> 

                <div class="dropdown">
    <button class="dropbtn">Staff Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addnewstaff2.php">add new  staff</a>
      <a href="php/stafflist.php"> View staff</a>
      <a href="addnewstaff.php">Update staff</a>
    </div>
  </div> 
                     

                <div class="dropdown">
    <button class="dropbtn">User Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="../index.php">add a new user</a>
      <a href="userlist.php">View users</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Crime Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="crime.php">add a new crime</a>
      <a href="crimelist.php">View crime</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Block Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="block.php">add a new block</a>
      <a href="blocklist.php">View block</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Next Skin Information
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addskin1.php">Add new Next Skin</a>
      <a href="skinlist.php">View Next Skin</a>
      <a href="addskin.php">Update Next Skin</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Prisoner Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactPrisoner1.php">Add Activity</a>
      <a href="prisoneractList.php">View Activity</a>
      <a href="addactPrisoner.php">Update Activity</a>
    </div>
  </div> 


                <div class="dropdown">
    <button class="dropbtn">Staff Activity
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addactStaff1.php">Add Activity</a>
      <a href="StaffactList.php">View Activity</a>
      <a href="addactStaff.php">Update Activity</a>
    </div>
  </div> 

  </div>

   <div id="subcontainer5">
    <h1>Staff Information</h1>
  </div>

   <div id="subcontainer6">

        <h3>Add prisoner Information</h3>
<?php require_once 'processPrison.php'; ?>


<?php

if(isset($_SESSION['message'])): ?>

  <div class="alert alert-<?=$_SESSION['msg_type']?>">
 
    <?php
    echo $_SESSION['message'];
    unset($_SESSION ['message']);
    ?>

</div>
<?php endif ?>

    <div class="container">

<?php
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));
$result = $mysqli ->query("SELECT * FROM skin ORDER BY skinID ASC") or die($mysqli->error);
 //pre_r($result);
?>



<div class="row justify-content-center">
  <form action="processSkin.php" method="POST">

    <div class="input-group">
    <div class="form-group">
    <label> ID Number </label>
    <input type="text" name="skinIDNumber" class="form-control"
    value="<?php echo $skinIDNumber; ?>" placeholder="Enter Skin ID Number" required>
    <span class ="help-block"></span>
    </div>

    <div class="input-group">
    <div class="form-group">
    <label> First Name </label>
    <input type="text" name="firstname" class="form-control"
    value="<?php echo $firstname; ?>" placeholder="Enter First Name" required>
    <span class ="help-block"></span>
    </div>

    
    <div class="form-group">
    <label> Last Name </label>
    <input type="text" name="lastname" class="form-control"
    value="<?php echo $lastname; ?>" placeholder="Enter Last Name" required>
    </div>

    <div class="form-group">
    <label> Phone Number </label>
    <input type="text" name="phonenumber"  class="form-control"
    value="<?php echo $phonenumber; ?>" placeholder="Enter Phone number" required> 
    </div>

    <div class="form-group">
    <label> Address </label>
    <input type="text" name="address"  class="form-control"
    value="<?php echo $address; ?>" placeholder="Enter Address" required> 
    </div>

    <div class="form-group">
    <label> Gender </label>
    <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="female") echo "checked";?>
    value="female">Female

    <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="male") echo "checked";?>
    value="male">Male

     <input type="radio" name="gender"  class="form-control"
    <?php if (isset($gender) && $gender=="other") echo "checked";?>
    value="other">Other

    <div class="form-group">
     <label for="relation"> Choose a Relation: </label>
    <select name="relation" style="width: -webkit-fill-available;
    height: 77px; font-size: inherit;">
      <option value="Undefined">Undefined</option>
      <option value="Parent">Parent</option>
      <option value="Sibling">Sibling</option>
      <option value="Son">Son</option>
      <option value="Friend">Friend</option>
      <option value="Other">Other</option>
    </select>
    </div>

    <div class="form-group">
    <label> Prisoner ID </label>
    <input type="text" name="prisonerID"  class="form-control"
    value="<?php echo $prisonerID; ?>" placeholder="Enter Prisoner ID" required> 
    </div>


    <div class="form-group">
      <?php 
        if ($update == true):
      ?>

    <button type="submit" class="btn btn-info" name="update">Update</button>
    <?php else: ?>
    <button type="submit" class="btn btn-primary" name="save">Save</button>
    <?php endif; ?>
    </div>

  </form>
</div>
          <div class="input-group">
          <div class="nav">
          </div>
            <div class="form-group">
          </div>              
      </form>
    </div>
    </div>  
  </div>
</div>
</div>

        <div id="subcontainer7">
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||

            </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p>
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
</section>


              <a href="../../pages/about.php" style="margin-left: 1490px; text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">|| Logout ||</a></li>
            </ul>

