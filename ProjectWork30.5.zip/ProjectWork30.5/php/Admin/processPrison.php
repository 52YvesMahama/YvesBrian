<?php


session_start();
$mysqli = new mysqli('localhost', 'root', '', 'prison') or die(mysql_error($mysqli));

$prisonerID = 0;
$update = false;

$IDNumber = '';
$firstname = '';
$lastname = '';
$phonenumber = '';
$address = '';
$dob = '';

$status = '';
$gender = '';




if (isset($_POST['save'])){





	$prisonerID = $_POST['prisonerID'];
	$IDNumber = $_POST['IDNumber'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$dob = $_POST['dob'];

	#echo "dob";


	# Calculate the age
	// echo date("Y/m/d") 
	var_dump();

	# Get date 

	# 

	$status = $_POST['status'];
	$gender = $_POST['gender'];


	$_SESSION['message'] = "Record has been saved!";
	$_SESSION['msg_type'] = "success";

	$mysqli->query("INSERT INTO inmates (IDNumber, firstname, lastname, phonenumber, address, dob, status, gender) VALUES('$IDNumber', '$firstname',  '$lastname', '$phonenumber', '$address', '$dob', '$status', '$gender') ") or 
	die($mysqli->error);

		header("location: successful.php");
}


if (isset($_GET['delete'])){
	$prisonerID = $_GET['delete'];
	$mysqli->query("DELETE FROM inmates WHERE prisonerID=$prisonerID") or die($mysqli->error());



	$_SESSION['message'] = "Record has been deleted!";
	$_SESSION['msg_type'] = "danger";

		header("location: addNewPrisoner.php");

}

if (isset($_GET['edit'])){
	$prisonerID = $_GET['edit'];
	$update = true;
	$result = $mysqli->query("SELECT * FROM inmates WHERE prisonerID=$prisonerID") or die($mysqli->error());
	// if (count($result) == 1 ){
	if (mysqli_num_rows($result) == 1 ){
		$row = $result->fetch_array();

	
	$IDNumber = $row['IDNumber'];
	$firstname = $row['firstname'];
	$lastname = $row['lastname'];
	$phonenumber = $row['phonenumber'];
	$address = $row['address'];
	$dob = $row['dob'];
	$status = $row['status'];
	$gender = $row['gender'];
	}

}

if (isset($_POST['update'])){
	$prisonerID = $_POST['prisonerID'];
	$IDNumber = $_POST['IDNumber'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$phonenumber = $_POST['phonenumber'];
	$address = $_POST['address'];
	$dob = $_POST['dob'];
	$status = $_POST['status'];
	$gender = $_POST['gender'];

		$mysqli->query("UPDATE inmates SET IDNumber= '$IDNumber', firstname='$firstname', lastname='$lastname', phonenumber ='$phonenumber', address='$address', dob='$dob', status='$status', gender='$gender' WHERE prisonerID=$prisonerID")or die($mysqli->error);

		$_SESSION['message'] = "Record has been updated!";
		$_SESSION['msg_type'] = "warning";

		header("location: successful.php");

}