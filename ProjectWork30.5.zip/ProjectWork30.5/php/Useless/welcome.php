<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
      <link rel="stylesheet" type="text/css" href="../css/welcome.css">
<!--  -->
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; background-color: #808080;
}

.nav ul {
  list-style: none;
  background-color: #444;
  text-align: center;
  padding: 0;
  margin: 0;
}
.nav ul {
  list-style: none;
  background-color: #444;
  text-align: center;
  margin-top: 10px;
  padding: 0;
  margin: 0;
}
.nav li {
  font-family: 'Oswald', sans-serif;
  font-size: 1.2em;
  line-height: 40px;
  height: 40px;
  border-bottom: 1px solid #888;
}

.nav a {
  text-decoration: none;
  color: #fff;
  display: block;
  transition: .3s background-color;
}
 
.nav a:hover {
  background-color: #005f5f;
}
 
.nav a.active {
  background-color: #fff;
  color: #444;
  cursor: default;
}

@media screen and (min-width: 600px) {
  .nav li {
    width: 120px;
    border-bottom: none;
    height: 50px;
    line-height: 50px;
    font-size: 1.4em;
  }
 
  /* Option 1 - Display Inline */
  .nav li {
    display: inline-block;
    margin-right: -4px;
  }


    </style>
</head>
<body>
    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to the Prison Management System.</h1>
    </div>
    <p>
        <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>
    <!-- Bar of windows  home, contact about us... -->

    <div class="nav">
      <ul>
        <li class="home"><a href="../index.html">Home</a></li>
        <li class="about"><a href="#">Staff</a></li>
        <li class="contact"><a href="add-record-form.php">new prisoner</a></li>
        <li class="about"><a href="results.php">All prisoners</a></li>
        <li class="about"><a href="crimes.php">crimes</a></li>

      </ul>
    </div>
<!-- <h2> Sorting crimes by types </h2>
 --><body>
  <section class="container">

  <div id="subcontainer2">
    <h2> Sorting crimes by types </h2>

  <!-- subcontainer2 is for body section
 -->


      </ul>
    </div>
</p>


<!--
<p>
      <div class="nav">
      <ul>
        <li class="home"><a href="tasks/Burglary.php">Burglary</a></li>
        <li class="about"><a href="tasks/abuse">abuse</a></li>
        <li class="contact"><a href="tasks/crime">crime</a></li>
        <li class="about"><a href="tasks/fraude">fraude</a></li>
      </ul>
    </div>
</p>

<p>
      <div class="nav">
      <ul>
        <li class="home"><a href="tasks/vol.php">Carjacking</a></li>
        <li class="about"><a href="#">Theft</a></li>
        <li class="contact"><a href="add-record-form.php">violence</a></li>
        <li class="about"><a href="mysql-select-query.php">Corruption</a></li>
      </ul>
    </div>
</p>
<p>
      <div class="nav">
      <ul>
        <li class="home"><a href="tasks/vol.php">Carjacking</a></li>
        <li class="about"><a href="#">Theft</a></li>
        <li class="contact"><a href="add-record-form.php">violence</a></li>
        <li class="about"><a href="mysql-select-query.php">Corruption</a></li>
      </ul>
    </div>
</p>
<h2> Sorting prisoners by address </h2>
<p>
      <div class="nav">
      <ul>
        <li class="home"><a href="tasks/vol.php">Brazil</a></li>
        <li class="about"><a href="#">Uruguay</a></li>
        <li class="contact"><a href="add-record-form.php">Argentina</a></li>
        <li class="about"><a href="mysql-select-query.php">Germani</a></li>
      </ul>
    </div>
</p>
<p>
      <div class="nav">
      <ul>
        <li class="home"><a href="tasks/vol.php">Goma</a></li>
        <li class="about"><a href="#">Norvege</a></li>
        <li class="contact"><a href="add-record-form.php">Spain</a></li>
        <li class="about"><a href="mysql-select-query.php">Argentina</a></li>
      </ul>
    </div>
</p>
<p>
      <div class="nav">
      <ul>
        <li class="home"><a href="tasks/vol.php">Brazil</a></li>
        <li class="about"><a href="#">Uruguay</a></li>
        <li class="contact"><a href="add-record-form.php">Argentina</a></li>
        <li class="about"><a href="mysql-select-query.php">Germani</a></li>
      </ul>
    </div>
</p>
<p>
      <div class="nav">
      <ul>
        <li class="home"><a href="tasks/vol.php">Goma</a></li>
        <li class="about"><a href="#">Norvege</a></li>
        <li class="contact"><a href="add-record-form.php">Spain</a></li>
        <li class="about"><a href="mysql-select-query.php">Argentina</a></li>
      </ul>
    </div>
</p>
</div> -->

<p>
</p>


</div>
</section>
</body>
</section>


</head>

</header>