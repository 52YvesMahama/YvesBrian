<?php
	include_once 'config.php';



	$username = $_POST['username'];
	$pwd = $_POST['pwd'];
	$staff_id = $_POST['staff_id'];
	$type = $_POST['type'];


	$sql = "INSERT INTO users (username, password, staff_id, type) VALUES ('$username', '$pwd', '$staff_id', '$type')";

echo "$sql";

	mysqli_query($link, $sql);


//	header("location: home.php");
?>