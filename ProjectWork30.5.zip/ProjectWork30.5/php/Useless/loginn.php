<?php
	include_once 'config.php';



	$username = $_POST['username'];
	$pwd = $_POST['pwd'];
	$staff_id = $_POST['staff_id'];
	$type = $_POST['type'];

// read from the DB
	// $sql = "INSERT INTO users (username, password, staff_id, type) VALUES ('$username', '$pwd', '$staff_id', '$type')";
	$sql = "SELECT * from users where username = '$username' limit 1";

// echo "$sql";

//	mysqli_query($link, $sql); 

	$result = mysqli_query($link, $sql);


//	header("location: index.php");

	echo "$sql";

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="loginn.php" method="POST"> 
	<input type="text" name="username" placeholder="username">
	<br> 	<br> 
	<input type="password" name="pwd" placeholder="password">
	<br>
	<br>
	<button type="submit" name="submit"> Login</button>
</form>


</body>
</html>