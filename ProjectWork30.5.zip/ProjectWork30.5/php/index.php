<!DOCTYPE html>
  <html>
    <head>
	<meta name="viewport" content="width=device-width, initial-scale=1">  
    </head>
        <link rel="stylesheet" type="text/css" href="../css/csslog1.css">

          <title>Prison MUNZENZE</title>
  <style>
    /*Form for Sign Up | Sign in*/
.header {
  width: 30%;
  margin: 50px auto 0px;
  color: white;
  background: #999999; 
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
form, .content {
  width: 30%;
  margin: 0px auto;
  padding: 20px;
  border: 1px solid #B0C4DE;
  background: white;
  border-radius: 10px 10px 10px 10px;
  background-color: rgba(52, 73, 94, 0.7);

}
.input-group {
  margin: 10px 0px 10px 0px;
}

.input-group label {
  display: block;
  text-align: left;
  margin: 3px;
  color: aliceblue;
  padding: 6px;
}
.input-group input {
  height: 30px;
  width: 93%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;

}
.btn {
  padding: 10px;
  font-size: 15px;
  color: white;
  background: #5F9EA0;
  border: none;
  border-radius: 5px;
  width: 150px;
  margin-right: 310px;
  margin-top: 17px;
}
.error {
  width: 92%; 
  margin: 0px auto; 
  padding: 10px; 
  border: 1px solid #a94442; 
  color: #a94442; 
  background: #f2dede; 
  border-radius: 5px; 
  text-align: left;
}
.success {
  color: #3c763d; 
  background: #dff0d8; 
  border: 1px solid #3c763d;
  margin-bottom: 20px;
}


</style>
          <body>
          <section class="container">
              <div id="subcontainer1">
                    <center><h1>The Ministry of Interior and Department of National Security. </h1></center>
                      <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
                            <h3>Correction & rehabilitation centre</h3>
                </div>
                <div id="subcontainer2">
                   <div class="nav">
                      <ul>
                        <li class="home"><a href="../index.html">Home</a></li>
                        <li class="contact"><a href="../pages/contact.php">Contact</a></li>
                        <li class="about"><a href="../pages/about.php">About Us</a></li>
                        <li class="about"><a class="active" href="Login.php" style="margin-left: 400px; width: 100px;">Logout</a></li>
                      </ul>
                   </div>

                <div id="subcontainer3">
                  <body>

    <div class="container">
    <div class="wrapper">
<!--     <div class="header">
 -->    <h2>SignUp</h2>
  </div>


			<form action="signup.php" method="POST"> 
			    <div class="input-group">
			        <div class="form-group">
			          	<label>Username</label>
				<input type="text" name="username" class="form-control" required>
					<span class="help-block"></span>
					</div>
			        
			        <div class="input-group">
			          	<label>Password</label>
				<input type="password" name="pwd" class="form-control"required>
					<span class="help-block"></span>
					</div>

			        <div class="input-group">
			          	<label>Staff ID</label>
				<input type="text" name="staff_id" class="form-control" required>
					<span class="help-block"></span>
				    </div>

			        <div class="input-group">
			          	<label>Type</label>
				<input type="text" name="type" class="form-control" required>
					<span class="help-block"></span>
				    </div>

            <div class="input-group">
				<button type="submit" class="btn" name="submit"> Sign up</button>
			</div>
			</form>
		</div>  
	</div>
</div>

            <div id="subcontainer4">
            
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="../pages/contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="../pages/about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p>

Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>
</footer>
          </div>
        </div>
      </div>

            </div>
          </section>
       </body> 
    </head>
  </html> 