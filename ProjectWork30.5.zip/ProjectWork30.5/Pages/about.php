<!DOCTYPE html>
  <html>
    <head>
    </head>
        <link rel="stylesheet" type="text/css" href="../css/css.css">
        <link rel="stylesheet" type="text/css" href="../css/cssY.css">
        <title>Prison Munzenze</title>
          <body>
          <section class="container">
              <div id="subcontainer1">
                    <center><h1>The Ministry of Interior and Department of National Security. </h1></center>
                      <h2>MUNZENZE PRISON MANAGEMENT  SYSTEM</h2>
                            <h3>Correction & rehabilitation centre</h3>
                </div>
                <div id="subcontainer2">
                   <div class="nav">
                      <ul>
                        <li class="home"><a href="../index.html">Home</a></li>
                        <li class="contact"><a  href="contact.php">Contact</a></li>
                        <li class="about"><a class="active" href="about.php">About Us</a></li>
                    </ul>
                   </div>
                   <body>


                <div id="subcontainer3">
                  <body>
                    <p>
                      Welcome
                    </p>

</body>
</div>
</div>
</section>
  <h2>ABOUT US</h2>
<p>
</p>
<hr>

<!-- form for about us takes place here
 -->

<div class="about-section">
  <p>We are under the govermnent ministry of interior security </p>
  <p>Our management is under 3 big persons in the institution</p>
</div>

<h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="../images/image4.jpg" alt="Jane" style="width:298px; height: 300px">
      <div class="container1">
        <h2>Rostand Bapolisi </h2>
        <p class="title">CEO & Director</p>
        <p>Manages the entire institution of the prison
        with the help of ICT.</p>
        <p>+243 991 899 923</p>
        <p>rostand@gmail.com</p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="../images/image6.jpg" alt="Jane" style="width:298px; height: 300px">
      <div class="container1">
        <h2>Marcel Thibula</h2>
        <p class="title">Deputy Director</p>
        <p>Manages the security and the environment of the
         prison</p>
        <p>+243 991 345 678</p>
        <p>Marcel@gmail.com</p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="../images/image7.jpg" alt="Jane" style="width:298px; height: 300px">
      <div class="container1">
        <h2>Evyline Mutondo</h2>
        <p class="title">Secretary </p>
        <p>Manages the institution in public relations and well fair and being </p>
        <p>+243 991 345 678</p>
        <p>evelyne@gmail.com</p>

      </div>
    </div>
  </div>
</div>
</section> 
</div>


                  </body>
                </div>
                  <div id="subcontainer4">
                      <footer>
        <div class="col-md-3 mb-5">
          <ul class="list-unstyled footer-link">

              || <a href="../index.html" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Home</a></li> ||
              <a href="contact.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">Contact</a></li> ||
              <a href="about.php" style="text-decoration: none; color: darkorange;
               font-size: 16px; font-family: cursive; }">About Us</a></li> ||
            </ul>
          </div>

        <div class="row">
          <div class="col-12 text-md-center text-left">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Your Company <i class="fa fa-heart-o" aria-hidden="true"></i> Designed by <a href="https://yvesmahama.com" target="_blank" style="color: darkorange;text-decoration: none;
}">Mhma52</a>

                  </div>
                </div>
              </div>
            </div>
          </section>
       </body> 
    </head>
  </html> 